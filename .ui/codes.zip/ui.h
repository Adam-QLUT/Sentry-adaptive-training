//
// Created by RM UI Designer
// Dynamic Edition
//

#ifndef UI_H
#define UI_H
#ifdef __cplusplus
extern "C" {
#endif

#include "ui_interface.h"

#include "ui_Omni.h"
#include "ui_default.h"

#ifdef __cplusplus
}
#endif

#endif // UI_H
