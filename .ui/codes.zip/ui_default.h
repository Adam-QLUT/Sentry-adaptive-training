//
// Created by RM UI Designer
// Dynamic Edition
//

#ifndef UI_default_H
#define UI_default_H

#include "ui_interface.h"




#ifdef MANUAL_DIRTY

#endif

void ui_init_default();
void ui_update_default();

#endif // UI_default_H
